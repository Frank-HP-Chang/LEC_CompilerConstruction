int x;
float y;
x + y;
y - x;
x = y;
3 + 3.14;
3.0 + 3.14;
x % y;
y % 3;

3 && true;
false || 2 + 2;

while (1.0) {
	print(1.0);
}

while (x + 1) {
	print(x);
}

if (2.0) {
	print(2.0);
}

if (x) {
	print(x);
}