int x = 0;
if (x == 0) { /* if */
	print("Hello");
	/* print
	a Hello with
	newline */
}

if (x != 0) { /* if else */
	float y = 3.14;
	print("If x != ");
	print(0);
	print(y);
} 
else {
	float z = 6.6;
	print("If x == ");
	print(0);
	print(z);
}

int y = 1;
if (x != 0) { // else if
	float y = 3.14;
	print("If x != ");
	print(0);
	print(y);
} else if (y != 0) {
	float z = 6.6;
	print("If y != ");
	print(0);
	print(z);
}

if (x != 0) { // long if else if
	float y = 3.14;
	print("If x != ");
	print(0);
	print(y);
} else if (y != 0) {
	float z = 6.6;
	print("If y != ");
	print(0);
	print(z);
} 
else if (y == 0)
{
	float zz = 6.66;
	print("If y == ");
	print(0);
	print(zz);
} else {
	print("else");
}