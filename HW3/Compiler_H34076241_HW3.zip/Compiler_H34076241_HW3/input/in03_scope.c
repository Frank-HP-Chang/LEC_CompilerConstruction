int height = 99;
int i = 1;
while(i > 0)
{
    i--;
    float width = 3.14;
    print(width);
    print("\n");
    print(height);
    print("\n");
}
float length;
int j = 1;
i = 1 ;
while(i > 0)
{
    string length = "hello world";
    i-- ;
    while(j > 0)
    {
        j--;
        bool length = true;
        print(length);
        print("\n");
    }
    print(length);
    print("\n");
}
print(length);