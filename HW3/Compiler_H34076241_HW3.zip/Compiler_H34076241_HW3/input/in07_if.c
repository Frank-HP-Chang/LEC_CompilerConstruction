int x = 0;
if(x == 0){ /* if */
	print("Hello");
	/* print
	a Hello with
	newline */
}