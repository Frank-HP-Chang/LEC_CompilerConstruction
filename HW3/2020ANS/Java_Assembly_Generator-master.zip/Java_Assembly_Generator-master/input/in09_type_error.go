var x int32
var y float32
x + y
y - x
x = y
3 + 3.14
3.0 + 3.14
x % y
y % 3

3 && true
false || 2 + 2

for 1.0 {
	println(1.0)
}

for x + 1 {
	println(x)
}

if 2.0 {
	println(2.0)
}

if x {
	println(x)
}