int X;
int y = 5;
float a = 6.2555, b = 3.14;
bool u_u = false;
string A213 = "abc";